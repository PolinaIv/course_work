function str = dblslash(str)
% Doubles every backslash in string

str = strrep(str, '\', '\\');

end

